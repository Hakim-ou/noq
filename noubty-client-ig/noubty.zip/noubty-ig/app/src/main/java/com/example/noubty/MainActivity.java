package com.example.noubty;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.lib.APIRequest;
import com.lib.EventClass;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import static com.lib.APIRequest.isConnected;

public class MainActivity extends AppCompatActivity {
	private static String TAG = "MainActivity";

    public static Lock lock = new ReentrantLock();
    private Timer eventsUpdate;

    private Button scanButton;
	private static ListView eventsList;
	private static TreeSet<EventClass> orderedEvents;
	private static ArrayList<EventClass> events;
	private static Set<String> qrCodes;

	@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
	@Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

        scanButton = findViewById(R.id.scannbutton);
        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            	Intent i = new Intent(getApplicationContext(), Scanner.class);
                startActivity(i);
            }
        });

		eventsList = findViewById(R.id.listView);
		setEventsList(this);
	}

	@Override
	public void onResume () {
		super.onResume();
		eventsUpdate = new Timer();
		eventsUpdate.schedule(new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						Log.d(TAG, "updating is running");
						MainActivity.setEventsList(MainActivity.this);
					}
				});

			}
		}, 0, 3000);
	}

	@Override
	public void onPause() {
		eventsUpdate.cancel();
		super.onPause();
	}

	static class ListAdapter extends ArrayAdapter<EventClass> {

		Context context;
		ArrayList<EventClass> rEvents;

		ListAdapter(Context context, ArrayList<EventClass> rEvents) {
			super(context, R.layout.cell, R.id.title, rEvents);
			this.context = context;
			this.rEvents = rEvents;
		}

		@NonNull
		@Override
		public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
			LayoutInflater layoutInflater = (LayoutInflater) context.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View cell = layoutInflater.inflate(R.layout.cell, parent, false);
			ImageView image = cell.findViewById(R.id.image);
			TextView title = cell.findViewById(R.id.title);
			TextView turn = cell.findViewById(R.id.turn);

			image.setImageResource(events.get(position).getImage());
			title.setText(events.get(position).getTitle());
			if (events.get(position).getBeforeMe() < 1) title.setTextColor(Color.RED);
			turn.setText(events.get(position).getTurn());

			return cell;
		}
	}

	public static void setEventsList(Context context) {
		try {
			if (!isConnected()) {
				Log.d("checkConn", "No connection");
				Intent i = new Intent(context.getApplicationContext(), NoConnection.class);
				context.startActivity(i);
			} else {
				Log.d("checkConn", "Connected");
				lock.lock();
				loadEvents(context);
				ListAdapter adapter = new ListAdapter(context, events);
				eventsList.setAdapter(adapter);
				lock.unlock();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	String post(String url, String json) throws IOException {
		final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
		OkHttpClient client = new OkHttpClient();
		RequestBody body = RequestBody.create(JSON, json);
		Request request = new Request.Builder()
				.url(url)
				.post(body)
				.build();
		Response response = client.newCall(request).execute();
		return response.body().string();
	}

	/**
	 * load events using QR codes stored in cache
	 */
	public static void loadEvents(Context context) {
	    loadQRCodes(context);
		events = new ArrayList<>();
		orderedEvents = new TreeSet<>();
		String response;
		Set<String> toRemove = new HashSet<>();
		for (String code : qrCodes) {
			try {
				APIRequest rqt = new APIRequest(9);
				rqt.putExtra("code", Integer.parseInt(code));
				response = rqt.execute();
				JSONObject answer = new JSONObject(response);
				int error = answer.getInt("error");
				if (error == 0) {
					addEvent(new EventClass(answer.getString("title"), answer.getInt("myTurn"), answer.getInt("beforeMe")));
					Log.d("event added: ", answer.getString("title"));
				} else if (error == 9) {
					toRemove.add(code);
					SharedPreferences sp = context.getSharedPreferences("noubty_qr_codes.cache", MODE_PRIVATE);
					SharedPreferences.Editor edit = sp.edit();
					edit.remove(code);
					edit.apply();
				}
				//TODO error = 1 ??
			} catch (IOException | JSONException e) {
				e.printStackTrace();

			}
		}
		qrCodes.removeAll(toRemove);
		for (EventClass ev : orderedEvents)
			events.add(ev);
	}

	/**
	 * add event recently captured by QR scanner
	 */
	public static void addEvent(EventClass ev) {
		orderedEvents.add(ev);
	}

	/**
	 * add event recently captured by QR scanner
	 */
	public static void loadQRCodes(Context context) {
		SharedPreferences sp = context.getSharedPreferences("noubty_qr_codes.cache", MODE_PRIVATE);
		qrCodes = sp.getAll().keySet();
	}


}
