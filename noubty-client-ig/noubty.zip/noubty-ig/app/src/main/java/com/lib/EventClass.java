package com.lib;

import androidx.annotation.NonNull;

import com.example.noubty.Event;
import com.example.noubty.R;

public class EventClass implements  Comparable<EventClass> {
    private String title;
    private int image;
    private int myTurn;
    private int beforeMe;

    public EventClass(String title, int myTurn, int beforeMe) {
        this.title = title;
        this.myTurn = myTurn;
        this.beforeMe = beforeMe;
        this.image = R.drawable.event;
    }

    public static EventClass loadEvent(int qrCode) {
        //TODO
        return new EventClass("Title", 1, 0);
    }

    public String getTitle() {
        return title;
    }

    public int getImage() {
        return image;
    }

    public int getBeforeMe() {
        return beforeMe;
    }

    public String getTurn() {
        return (beforeMe < 1) ? "C'est votre tour !" :
                                "tour " + myTurn + " - " + beforeMe + " personnes en attente";
    }

    @NonNull
    @Override
    public String toString() {
        return title;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof EventClass)
            return beforeMe == ((EventClass)o).beforeMe && title.equals(((EventClass)o).title);
        else return false;
    }

    @Override
    public int compareTo(EventClass ev) {
        if (beforeMe > ev.beforeMe)
            return 1;
        if (beforeMe < ev.beforeMe)
            return -1;
        return title.compareTo(ev.title);
    }
}
